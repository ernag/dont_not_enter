/*************************************************************************
 *
 *   Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2010
 *
 *    File name   : Flash.c
 *    Description : FlashLoader  internal flash loader
 *
 *    History :
 *    1. Date        : July, 2010
 *       Author      : Stoyan Choynev
 *       Description : Initial revision
 *
 *
 *    $Revision: #13 $
 **************************************************************************/
#include <intrinsics.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef K60Fxxx
#include <freescale/MK60X256VMD100.h>
#else
#include <freescale/MK60N512VMD100.h>
#endif

#include "flash_loader.h"       /* The flash loader framework API declarations. */
#include "flash_loader_extra.h"

/* Flash controller definitions */
#define CCIF    (1<<7)
#define ACCERR  (1<<5)
#define FPVIOL  (1<<4)
#define MGSTAT0 (1<<0)

/*
** define flash command codes
*/
#define RD1BLK    0x00
#define RD1SEC    0x01
#define PGMCHK    0x02
#define RDRSRC    0x03
#define PGM4      0x06
#define PGM8      0x07
#define ERSBLK    0x08
#define ERSSCR    0x09
#define PGMSEC    0x0B
#define RD1ALL    0x40
#define RDONCE    0x41
#define PGMONCE   0x43
#define ERSALL    0x44
#define VFYKEY    0x45
#define PGMPART   0x80
#define SETRAM    0x81

typedef uint32_t flashunit;
typedef enum _MCG_ModeState_t
{
  MGC_FEI_STATE = 0, MGC_FEE_STATE, MGC_FBI_STATE,
  MGC_FBE_STATE, MGC_PEE_STATE, MGC_PBE_STATE,
  MGC_LP_STATE,  MGC_UNKNOWN_STATE
} MCG_ModeState_t;

/** default settings **/

/** external functions **/

/** external data **/

/** internal functions **/
static uint32_t CommandLaunch(void);
__no_init static uint32_t user_supply_prot;

/** public data **/
/** private data **/
__no_init static volatile uint32_t flashBase;

/** public functions **/

/** private functions **/
static void DisableWDT(void);

/*************************************************************************
 * Function Name: FlashInit
 * Parameters: Flash Base Address
 *
 * Return:  0 - Init Successful
 *          1 - Init Fail
 * Description: Init flash and build layout.
 *
 *************************************************************************/
#if USE_ARGC_ARGV
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags,
                   int argc, char const *argv[])
#else
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags)
#endif /* USE_ARGC_ARGV */
{
  uint32_t mcg_state;
  uint32_t ext_osc    = 0;
  uint32_t ext_quartz = 0;
  uint32_t int_osc    = 0;
  uint32_t *ext;

  /* Disable WDT*/
  DisableWDT();
#if USE_ARGC_ARGV
  user_supply_prot = 0;
  for(int i = 0; i < argc; i++)
  {
    /*if there is a partition arg*/
    if(strcmp("--enable_config_write", argv[i]) == 0)
    {
      user_supply_prot = 1;
    }
    else if(strcmp("--partition", argv[i]) == 0)
    {
      /*Erase All Blocks Command*/
      FTFL_FCCOB0 = ERSALL;
      if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;

      if(i < argc)
      {
        uint16_t partition = strtoul(argv[++i],0,0);
        /*Program Partition Command*/
        FTFL_FCCOB0 = PGMPART;
        FTFL_FCCOB4 = partition & 0xFF;
        FTFL_FCCOB5 = (partition>>8) & 0xFF;
        if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
      }
    }
    else if(strcmp("--ext_osc", argv[i]) == 0)
    {
        ext_osc = strtoul(argv[++i],0,0);
    }
    else if(strcmp("--ext_quartz", argv[i]) == 0)
    {
        ext_quartz = strtoul(argv[++i],0,0);
    }
    else if(strcmp("--int_osc", argv[i]) == 0)
    {
      int_osc = 1;
    }
  }
#else
  user_supply_prot = 1;
#endif

  /* init clock system */
  /* check current mode */
  if(MCG_C2 & MCG_C2_LP_MASK)
  {
    /* Some of LP modes */
    mcg_state = MGC_LP_STATE;
  }
  else if (   (MCG_C1_CLKS(0) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && ( (MCG_C1 & MCG_C1_IREFS_MASK))
           && (!(MCG_C6 & MCG_C6_PLLS_MASK))
           )
  {
    /* FEI mode */
    mcg_state = MGC_FEI_STATE;
  }
  else if (   (MCG_C1_CLKS(0) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && (!(MCG_C1 & MCG_C1_IREFS_MASK))
           && (!(MCG_C6 & MCG_C6_PLLS_MASK))
           )
  {
    /* FEE mode */
    mcg_state = MGC_FEE_STATE;
  }
  else if (   (MCG_C1_CLKS(1) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && ( (MCG_C1 & MCG_C1_IREFS_MASK))
           && (!(MCG_C6 & MCG_C6_PLLS_MASK))
           )
  {
    /* FBI mode */
    mcg_state = MGC_FBI_STATE;
  }
  else if (   (MCG_C1_CLKS(2) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && (!(MCG_C1 & MCG_C1_IREFS_MASK))
           && (!(MCG_C6 & MCG_C6_PLLS_MASK))
           )
  {
    /* FBE mode */
    mcg_state = MGC_FBE_STATE;
  }
  else if (   (MCG_C1_CLKS(0) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && ( (MCG_C6 & MCG_C6_PLLS_MASK))
           )
  {
    /* PEE mode */
    mcg_state = MGC_PEE_STATE;
  }
  else if (   (MCG_C1_CLKS(2) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && ( (MCG_C6 & MCG_C6_PLLS_MASK))
           )
  {
    /* PBE mode */
    mcg_state = MGC_PBE_STATE;
  }
  else
  {
    mcg_state  = MGC_UNKNOWN_STATE;
  }

  /* init clock system */
  if(   (ext_osc || ext_quartz)
     && (   (MGC_PEE_STATE != mcg_state)
         )
     )
  {
    int i;

    /* switch to Iref fast clock */
    MCG_C1  = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(1);
    MCG_C2 |= MCG_C2_IRCS_MASK;
    while(MCG_S_CLKST(1) !=(MCG_S_CLKST_MASK & MCG_S));

    /* try to switch to external clock with PLL/FLL (PLLF/FLLF ~25MHz) */
    /* init external clock type quartz or OSC */
    MCG_C2 &= ~MCG_C2_LP_MASK;

    ext = ext_osc?&ext_osc:&ext_quartz;
    if(*ext < 2000)
    {
      /* LF */
      MCG_C2 = (MCG_C2 & ~MCG_C2_RANGE_MASK) | MCG_C2_RANGE(0);
      mcg_state = MGC_FEE_STATE;
    }
    else if(*ext <= 8000)
    {
      /* HF */
      MCG_C2 = (MCG_C2 & ~MCG_C2_RANGE_MASK) | MCG_C2_RANGE(1);
      mcg_state = MGC_PEE_STATE;
    }
    else
    {
      /* VHF */
      MCG_C2 = (MCG_C2 & ~MCG_C2_RANGE_MASK) | MCG_C2_RANGE(2);
      mcg_state = MGC_PEE_STATE;
    }

    if(ext_osc)
    {
      MCG_C2 &=~MCG_C2_EREFS_MASK;
      OSC_CR |= OSC_CR_ERCLKEN_MASK;
    }
    else
    {
      MCG_C2 |= MCG_C2_EREFS_MASK | MCG_C2_HGO_MASK;
      OSC_CR |= OSC_CR_ERCLKEN_MASK;
      /* wait until OSC is ready */
      i = 100000;
      while(!(MCG_S_OSCINIT_MASK & MCG_S))
      {
        if(!--i)
        {
          goto set_fei;
        }
      }
    }

    if(MGC_FEE_STATE == mcg_state)
    {
      /* switch to FEE mode*/
      MCG_C4 &= 0x1F;
      for(i = 0; i < 8; i++)
      {
        if(39 >= ext_quartz)
        {
          break;
        }
        ext_quartz >>= 1;
      }
      if(7 < i)
      {
        goto set_fei;
      }

      MCG_C1 = (MCG_C1 & ~MCG_C1_FRDIV_MASK) | MCG_C1_FRDIV(i);
      MCG_C1&=~MCG_C1_IREFS_MASK;
      MCG_C1 = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(0);
      SIM_CLKDIV1 = 0;
    }
    else
    {
      /* switch to PEE mode*/
      /* find PLL predivider */
      for(i = 0; i <= 25; i++)
      {
        if((4000 > (*ext/(i+1))) && (2000 > (*ext/(i+2))))
        {
          break;
        }
      }
      if(25 < i)
      {
        /* use FEI mode */
        goto set_fei;
      }
      MCG_C5  = MCG_C5_PRDIV(i);
      MCG_C6 &=~MCG_C6_VDIV_MASK;
      MCG_C6 |= MCG_C6_VDIV(24);
      MCG_C5 |= MCG_C5_PLLCLKEN_MASK;

      /* wait until PLL lock */
      i = 10000;
      while(!(MCG_S_LOCK_MASK & MCG_S))
      {
        if(!--i)
        {
          goto set_fei;
        }
      }
      MCG_C6|= MCG_C6_PLLS_MASK;
      MCG_C1 = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(0);
      while(MCG_S_CLKST(3) != (MCG_S_CLKST_MASK & MCG_S));
      SIM_CLKDIV1 = 0;
    }
  }

  if(   (int_osc && (MGC_FEI_STATE != mcg_state))
     || (MGC_LP_STATE == mcg_state)
     || (MGC_UNKNOWN_STATE == mcg_state)
    )
  {
set_fei:
    /* switch to Iref fast clock */
    MCG_C1  = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(1);
    MCG_C2 |= MCG_C2_IRCS_MASK;
    while(MCG_S_CLKST(1) !=(MCG_S_CLKST_MASK & MCG_S));

    /* switch to internal clock with FLL (FFLL ~ 25MHz) */
    MCG_C6 &= ~MCG_C6_PLLS_MASK;
    MCG_C5 &= ~MCG_C5_PLLCLKEN_MASK;
    MCG_C1 |=  MCG_C1_IREFS_MASK;
    MCG_C1  = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(0);
    while(MCG_S_CLKST_MASK & MCG_S);
    SIM_CLKDIV1 = 0;
  }

  /* wait until command complete */
  while(!(FTFL_FSTAT & CCIF));
  /* Clear status */
  FTFL_FSTAT = ACCERR | FPVIOL;
  return (RESULT_OK);
}

/*************************************************************************
 * Function Name: FlashWrite
 * Parameters: block base address, offet in block, data size, ram buffer
 *             pointer
 * Return:  0 - Write Successful
 *          1 - Write Fail
 * Description. Writes data to Flash
 *************************************************************************/
uint32_t FlashWrite(void *block_start,
                    uint32_t offset_into_block,
                    uint32_t count,
                    char const *buffer)
{
uint32_t size;

union
{
  uint32_t  word;
  uint8_t   byte[4];
} dest;

  /*Set Write command*/
#ifdef K60Fxxx
  FTFL_FCCOB0 = PGM8;
  for(size = 0, dest.word = (uint32_t)block_start + offset_into_block;
      size < count; size += 8, dest.word += 8, buffer +=8 ) {

    if(dest.word == 0x408 && !user_supply_prot)
      continue;

    /*Set destination address*/
    FTFL_FCCOB1 = dest.byte[2];
    FTFL_FCCOB2 = dest.byte[1];
    FTFL_FCCOB3 = dest.byte[0];
    /*copy data*/
    FTFL_FCCOB8 = buffer[7];
    FTFL_FCCOB9 = buffer[6];
    FTFL_FCCOBA = buffer[5];
    FTFL_FCCOBB = buffer[4];
    FTFL_FCCOB4 = buffer[3];
    FTFL_FCCOB5 = buffer[2];
    FTFL_FCCOB6 = buffer[1];
    FTFL_FCCOB7 = buffer[0];
    if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  }
#else
  FTFL_FCCOB0 = PGM4;
  for(size = 0, dest.word = (uint32_t)block_start + offset_into_block;
      size < count; size += 4, dest.word += 4, buffer +=4 ) {

    if(dest.word == 0x40C && !user_supply_prot)
      continue;

    /*Set destination address*/
    FTFL_FCCOB1 = dest.byte[2];
    FTFL_FCCOB2 = dest.byte[1];
    FTFL_FCCOB3 = dest.byte[0];
    /*copy data*/
    FTFL_FCCOB4 = buffer[3];
    FTFL_FCCOB5 = buffer[2];
    FTFL_FCCOB6 = buffer[1];
    FTFL_FCCOB7 = buffer[0];
    if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  }
#endif


  return(RESULT_OK);
}

/*************************************************************************
 * Function Name: FlashErase
 * Parameters:  Block Address, Block Size
 *
 * Return: 0
 *
 * Description: Erase block
 *************************************************************************/
uint32_t FlashErase(void *block_start,
                    uint32_t block_size)
{
union
{
  uint32_t  word;
  uint8_t   byte[4];
} dest;

  dest.word = (uint32_t)block_start;
  /*Set Erase command*/
  FTFL_FCCOB0 = ERSSCR;
  /*Set destination address*/
  FTFL_FCCOB1 = dest.byte[2];
  FTFL_FCCOB2 = dest.byte[1];
  FTFL_FCCOB3 = dest.byte[0];
  /*Execute Command sequence*/
  CommandLaunch();

  /* Unlock device wneh erese sector 0*/
#if BLOCK_1K
  if(   (dest.word >= 0x400)
     && (dest.word < 0x800)
     && !user_supply_prot)
#else
  if(dest.word < 0x800 && !user_supply_prot)
#endif
  {
#ifdef K60Fxxx
    /* Write 8 bytes*/
    FTFL_FCCOB0 = PGM8;
    /*Set destination address*/
    FTFL_FCCOB1 = 0x00;
    FTFL_FCCOB2 = 0x04;
    FTFL_FCCOB3 = 0x08;
    /*data*/
    FTFL_FCCOB4 = 0xFF;
    FTFL_FCCOB5 = 0xFF;
    FTFL_FCCOB6 = 0xFF;
    FTFL_FCCOB7 = 0xFF;
    FTFL_FCCOB8 = 0xFF;
    FTFL_FCCOB9 = 0xFF;
    FTFL_FCCOBA = 0xFF;
    FTFL_FCCOBB = 0xFE;
#else
    /* Write 4 bytes*/
    FTFL_FCCOB0 = PGM4;
    /*Set destination address*/
    FTFL_FCCOB1 = 0x00;
    FTFL_FCCOB2 = 0x04;
    FTFL_FCCOB3 = 0x0C;
    /*data*/
    FTFL_FCCOB4 = 0xFF;
    FTFL_FCCOB5 = 0xFF;
    FTFL_FCCOB6 = 0xFF;
    FTFL_FCCOB7 = 0xFE;
#endif
    if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  }
  return(RESULT_OK);
}

OPTIONAL_SIGNOFF

uint32_t FlashSignoff(void)
{
  /*Cache Invalidate all four ways
    Bank 0*/
  FMC_PFB0CR = FMC_PFB0CR_CINV_WAY(0xF);
  /*Invalidate (clear) specification buffer and page buffer
    Bank 0*/
  FMC_PFB0CR |= FMC_PFB0CR_S_B_INV_MASK;

  return RESULT_OK;
}

/** private functions **/
static uint32_t CommandLaunch(void)
{
  /* Clear command result flags */
  FTFL_FSTAT = ACCERR | FPVIOL;
  /* Launch Command */
  FTFL_FSTAT = CCIF;
  /* wait command end */
  while(!(FTFL_FSTAT & CCIF));
  /*check for errors*/
  if(FTFL_FSTAT & (ACCERR | FPVIOL | MGSTAT0)) return(RESULT_ERROR);
  /*No errors retur OK*/
  return (RESULT_OK);
}

static void DisableWDT(void)
{
  WDOG_UNLOCK = 0xC520;
  WDOG_UNLOCK = 0xD928;
  WDOG_STCTRLH = 0;
}
