
DESCRIPTION
===========

Flash loader for internal flash of Freescale  KE04Z8 device.

CONFIGURATION
=============

The project contains configuration:

- Debug
Builds a flash loader for FlashKE1x devices. Uses 1KB RAM.
Output file: FlashKE04Z8.out
Macro file:  FlashKE04Z8.mac

USAGE
=====
The flash loader supports: writing the program flash
