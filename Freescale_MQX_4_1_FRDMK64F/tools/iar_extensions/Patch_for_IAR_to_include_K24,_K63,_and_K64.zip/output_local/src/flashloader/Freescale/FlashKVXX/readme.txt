
DESCRIPTION
===========

Flash loader for internal flash of Freescale  KVxx devices.

CONFIGURATION
=============

The project contains configuration:

- Debug
Builds a flash loader for FlashKVxx devices. Uses 8KB RAM.
Output file: FlashKV1x8K.out


USAGE
=====
The flash loader supports: writing the program flash

--enable_config_write - allow programming of 0x40C - 0x40F with user supplied
data, in other case flashloader afret erase of block 0 will write 0xFFFFFFFE
(unsecure state).
When is used "--ext_osc 50000" argument, the flashloader will try to initialize 
external oscillator circuit and FLL, frequency of the oscillators in kHz, 
on fault the internal oscillator will be used.
When is used "--ext_quartz 8000" argument, the flashloader will try to initialize 
external quartz resonator and FLL, frequency of the quartz is in kHz, 
on fault the internal oscillator will be used.
The "--int_osc" argument will force initialization of internal oscillator 
and FLL.
