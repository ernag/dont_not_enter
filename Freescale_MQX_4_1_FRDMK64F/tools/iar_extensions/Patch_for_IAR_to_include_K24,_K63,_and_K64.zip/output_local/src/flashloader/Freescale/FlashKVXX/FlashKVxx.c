/*************************************************************************
 *
 *   Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2013
 *
 *    File name   : FlashKVxx.c
 *    Description : Internal flash loader
 *
 *    History :
 *    1. Date        : July, 2010
 *       Author      : Stoyan Choynev
 *       Description : Initial revision
 *    2. Date        : 12 July, 2013
 *       Author      : Stanimir Bonev
 *       Description : port for KVxx series
 *
 *    $Revision: #2 $
 **************************************************************************/

#include <intrinsics.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <freescale/MKV10Z7.h>

#include "flash_loader.h"       // The flash loader framework API declarations.
#include "flash_loader_extra.h"

/* Flash controller definitions */
#define CCIF    (1<<7)
#define ACCERR  (1<<5)
#define FPVIOL  (1<<4)
#define MGSTAT0 (1<<0)

typedef enum _MCG_ModeState_t
{
  MGC_FEI_STATE = 0, MGC_FEE_STATE, MGC_FBI_STATE,
  MGC_FBE_STATE, MGC_LP_STATE,  MGC_UNKNOWN_STATE
} MCG_ModeState_t;

/*
** define flash command codes
*/
#define ERPS      0x09
#define WRP       0x06

typedef uint32_t flashunit;

/** default settings **/

/** external functions **/

/** external data **/

/** internal functions **/
static uint32_t CommandLaunch(void);
__no_init static uint32_t user_supply_prot;

/** public data **/
/** private data **/
__no_init static volatile uint32_t flashBase;

/** public functions **/
static void DisableWDT(void)
{
  WDOG_UNLOCK = 0xC520;
  WDOG_UNLOCK = 0xD928;
  WDOG_STCTRLH = 0;
}

/*************************************************************************
 * Function Name: FlashInit
 * Parameters: Flash Base Address
 *
 * Return:  0 - Init Successful
 *          1 - Init Fail
 * Description: Init flash and build layout.
 *
 *************************************************************************/
#if USE_ARGC_ARGV
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags,
                   int argc, char const *argv[])
#else
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags)
#endif /* USE_ARGC_ARGV */
{
  uint32_t mcg_state;
  uint32_t ext_osc    = 0;
  uint32_t ext_quartz = 0;
  uint32_t int_osc    = 0;
  uint32_t *ext;

  DisableWDT();
  user_supply_prot = 0;

#if USE_ARGC_ARGV
  for(int i = 0; i < argc; i++)
  {
    /*if there is a partition arg*/
    if(strcmp("--enable_config_write", argv[i]) == 0)
    {
      user_supply_prot = 1;
    }
    else if(strcmp("--ext_osc", argv[i]) == 0)
    {
        ext_osc = strtoul(argv[++i],0,0);
    }
    else if(strcmp("--ext_quartz", argv[i]) == 0)
    {
        ext_quartz = strtoul(argv[++i],0,0);
    }
    else if(strcmp("--int_osc", argv[i]) == 0)
    {
      int_osc = 1;
    }
  }
#endif

  /* init clock system */
  /* check current mode */
  if(MCG_C2 & MCG_C2_LP_MASK)
  {
    /* Some of LP modes */
    mcg_state = MGC_LP_STATE;
  }
  else if (   (MCG_C1_CLKS(0) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && ( (MCG_C1 & MCG_C1_IREFS_MASK))
           )
  {
    /* FEI mode */
    mcg_state = MGC_FEI_STATE;
  }
  else if (   (MCG_C1_CLKS(0) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && (!(MCG_C1 & MCG_C1_IREFS_MASK))
           )
  {
    /* FEE mode */
    mcg_state = MGC_FEE_STATE;
  }
  else if (   (MCG_C1_CLKS(1) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && ( (MCG_C1 & MCG_C1_IREFS_MASK))
           )
  {
    /* FBI mode */
    mcg_state = MGC_FBI_STATE;
  }
  else if (   (MCG_C1_CLKS(2) == (MCG_C1 & MCG_C1_CLKS_MASK))
           && (!(MCG_C1 & MCG_C1_IREFS_MASK))
           )
  {
    /* FBE mode */
    mcg_state = MGC_FBE_STATE;
  }
  else
  {
    mcg_state  = MGC_UNKNOWN_STATE;
  }

  /* init clock system */
  if(   (ext_osc || ext_quartz)
     && (   (MGC_FEE_STATE != mcg_state)
         )
     )
  {
    int i;
    /* switch to Iref fast clock */
    MCG_C1  = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(1);
    MCG_C2 |= MCG_C2_IRCS_MASK;
    while(MCG_S_CLKST(1) !=(MCG_S_CLKST_MASK & MCG_S));
    mcg_state = MGC_FBI_STATE;

    /* try to switch to external clock with FLL (FLLF ~25MHz) */
    /* init external clock type quartz or OSC */
    MCG_C2 &= ~MCG_C2_LP_MASK;

    ext = ext_osc?&ext_osc:&ext_quartz;
    if(*ext < 2000)
    {
      /* LF */
      MCG_C2 = (MCG_C2 & ~MCG_C2_RANGE0_MASK) | MCG_C2_RANGE0(0);
    }
    else if(*ext <= 8000)
    {
      /* HF */
      MCG_C2 = (MCG_C2 & ~MCG_C2_RANGE0_MASK) | MCG_C2_RANGE0(1);
      *ext >>= 5;
    }
    else
    {
      /* VHF */
      MCG_C2 = (MCG_C2 & ~MCG_C2_RANGE0_MASK) | MCG_C2_RANGE0(2);
      *ext >>= 5;
    }

    if(ext_osc)
    {
      MCG_C2 &=~MCG_C2_EREFS0_MASK;
      OSC_CR |= OSC_CR_ERCLKEN_MASK;
    }
    else
    {
      MCG_C2 |= MCG_C2_EREFS0_MASK | MCG_C2_HGO0_MASK;
      OSC_CR |= OSC_CR_ERCLKEN_MASK;
      /* wait until OSC is ready */
      i = 100000;
      while(!(MCG_S_OSCINIT0_MASK & MCG_S))
      {
        if(!--i)
        {
          goto set_fei;
        }
      }
    }

    /* switch to FEE mode*/
    MCG_C4 &= 0x1F;
    for(i = 0; i < 8; i++)
    {
      if(39 >= *ext)
      {
        break;
      }
      *ext >>= 1;
    }
    if(7 < i)
    {
      goto set_fei;
    }

    MCG_C1 = (MCG_C1 & ~MCG_C1_FRDIV_MASK) | MCG_C1_FRDIV(i);
    MCG_C1&=~MCG_C1_IREFS_MASK;
    MCG_C1 = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(0);
    while(MCG_S_CLKST_MASK & MCG_S);
    SIM_CLKDIV1 = 0; // div1 = 1:1; div4 = 1:1 div5 disable
    mcg_state = MGC_FEE_STATE;
  }

  if(   (int_osc && (MGC_FEI_STATE != mcg_state))
     || (MGC_LP_STATE == mcg_state)
     || (MGC_UNKNOWN_STATE == mcg_state)
    )
  {
set_fei:
    /* switch to Iref fast clock */
    MCG_C1  = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(1);
    MCG_C2 |= MCG_C2_IRCS_MASK;
    while(MCG_S_CLKST(1) !=(MCG_S_CLKST_MASK & MCG_S));

    /* switch to internal clock with FLL (FFLL ~ 25MHz) */
    MCG_C1 |=  MCG_C1_IREFS_MASK;
    MCG_C1  = (MCG_C1 & ~MCG_C1_CLKS_MASK) | MCG_C1_CLKS(0);
    while(MCG_S_CLKST_MASK & MCG_S);
    SIM_CLKDIV1 = 0; // div1 = 1:1; div4 = 1:1 div5 disable
  }

  SIM_FCFG1 = 0; 	 /* Flash is enabled */
  /* wait until command complete */
  while(!(FTFA_FSTAT & CCIF));
  /* Clear status */
  FTFA_FSTAT = ACCERR | FPVIOL;

  return (RESULT_OK);
}

/*************************************************************************
 * Function Name: FlashWrite
 * Parameters: block base address, offet in block, data size, ram buffer
 *             pointer
 * Return:  0 - Write Successful
 *          1 - Write Fail
 * Description. Writes data to Flash
 *************************************************************************/
uint32_t FlashWrite(void *block_start,
                    uint32_t offset_into_block,
                    uint32_t count,
                    char const *buffer)
{
uint32_t size;

union
{
  uint32_t  word;
  uint8_t   byte[4];
} dest;

  /*Set Write command*/
  while(!(FTFA_FSTAT & CCIF));

  for(size = 0, dest.word = (uint32_t)block_start + offset_into_block;
      size < count; size += 4, dest.word += 4, buffer += 4)
  {
    if(dest.word == 0x40c && !user_supply_prot)
      continue;

    /*Set destination address and command*/
    FTFA_FCCOB0 = WRP;
    FTFA_FCCOB1 = dest.byte[2];
    FTFA_FCCOB2 = dest.byte[1];
    FTFA_FCCOB3 = dest.byte[0];
    /*copy data*/
    FTFA_FCCOB4 = buffer[3]; /* +0 */
    FTFA_FCCOB5 = buffer[2]; /* +1 */
    FTFA_FCCOB6 = buffer[1]; /* +2 */
    FTFA_FCCOB7 = buffer[0]; /* +3 */

    if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  }
  return(RESULT_OK);
}

/*************************************************************************
 * Function Name: FlashErase
 * Parameters:  Block Address, Block Size
 *
 * Return: 0
 *
 * Description: Erase block
 *************************************************************************/
uint32_t FlashErase(void *block_start,
                    uint32_t block_size)
{
union
{
  uint32_t  word;
  uint8_t   byte[4];
} dest;

  dest.word = (uint32_t)block_start;
  /*Set Erase command*/
  while(!(FTFA_FSTAT & CCIF));

  FTFA_FCCOB0 = ERPS;
  FTFA_FCCOB1 = dest.byte[2];
  FTFA_FCCOB2 = dest.byte[1];
  FTFA_FCCOB3 = dest.byte[0];

  /*Execute Command sequence*/
  CommandLaunch();

  /* Unlock device wneh erese sector 0*/
  if(   (dest.word >= 0x400)
     && (dest.word < 0x800)
     && !user_supply_prot)
  {

    dest.word = 0x40C;
    FTFA_FCCOB0 = WRP;
    FTFA_FCCOB1 = dest.byte[2];
    FTFA_FCCOB2 = dest.byte[1];
    FTFA_FCCOB3 = dest.byte[0];
    FTFA_FCCOB4 = 0xFF; /* 0x40F */
    FTFA_FCCOB5 = 0xFF; /* 0x40E */
    FTFA_FCCOB6 = 0xFF; /* 0x40D */
    FTFA_FCCOB7 = 0xFE; /* 0x40C */

    if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  }
  return(RESULT_OK);
}

/** private functions **/
static uint32_t CommandLaunch(void)
{
  /* Clear command result flags */
  FTFA_FSTAT = ACCERR | FPVIOL;
  /* Launch Command */
  FTFA_FSTAT = CCIF;
  /* wait command end */
  while(!(FTFA_FSTAT & CCIF));
  /*check for errors*/
  if(FTFA_FSTAT & (ACCERR | FPVIOL | MGSTAT0)) return(RESULT_ERROR);
  /*No errors retur OK*/
  return (RESULT_OK);
}
