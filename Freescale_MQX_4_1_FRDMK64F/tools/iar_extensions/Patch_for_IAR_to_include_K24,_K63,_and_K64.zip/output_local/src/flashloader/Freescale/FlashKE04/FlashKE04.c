/*************************************************************************
 *
 *   Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2013
 *
 *    File name   : Flash.c
 *    Description : FlashLoader for internal flash
 *
 *    History :
 *    1. Date        : July, 2013
 *       Author      : Stanimir Bonev
 *       Description : Initial revision
 *
 *
 *    $Revision: #2 $
 **************************************************************************/

#include <intrinsics.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "flash_loader.h"       	/* The flash loader framework API declarations. */
#include "flash_loader_extra.h"

/* target header files */
#include "MKE04Z4.h"

/*
** define flash command codes
*/
#define FTMRE_CMD_ERASE_VERIFY_ALL	    0x01
#define FTMRE_CMD_ERASE_VERIFY_BLOCK	  0x02
#define FLASH_CMD_ERASE_VERIFY_SECTION	0x03
#define FLASH_CMD_READONCE		          0x04
#define FLASH_CMD_PROGRAM		            0x06
#define FLASH_CMD_PROGRAMONCE		        0x07
#define FTMRE_CMD_ERASE_ALL		          0x08
#define FTMRE_CMD_ERASE_BLOCK		        0x09
#define FLASH_CMD_ERASE_SECTOR		      0x0A
#define FTMRE_CMD_UNSECURE		          0x0B
#define FLASH_CMD_BACKDOOR_ACCESS	      0x0C
#define FTMRE_CMD_SET_USER_MARGIN		    0x0D
#define FTMRE_CMD_SET_FACTORY_MARGIN		0x0E

/** default settings **/

/** external functions **/

/** external data **/

/** internal functions **/
static uint32_t CommandLaunch(void);

/** public data **/

/** private data **/

/** public functions **/

/*************************************************************************
 * Function Name: FlashInit
 * Parameters: Flash Base Address
 *
 * Return:  0 - Init Successful
 *          1 - Init Fail
 * Description: Init flash and build layout.
 *
 *************************************************************************/
#if USE_ARGC_ARGV
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags,
                   int argc, char const *argv[])
#else
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags)
#endif /* USE_ARGC_ARGV */
{
  /* */
  /* Disable watchdog*/
  /* Unlock */
  WDOG_CNT   = 0x20C5;
  WDOG_CNT   = 0x28D9;
  /* then disable it with 6 byte write */
  WDOG_TOVAL = 0xFFFF;
  /* WDOG_WIN = 0; // NOTE: this will cause HARDFAULT error */
  WDOG_WINH = 0xFF;
  WDOG_WINL = 0xFF;

  WDOG_CS2 = 0x01;
  WDOG_CS1 = 0x20; /* WDOGA = 1 to allow reconfigure watchdog at any time by executing an unlock sequence */

  /* wait until command complete */
  while (!(FTMRE_FSTAT & FTMRE_FSTAT_CCIF_MASK));

  /* Clear status */
  FTMRE_FSTAT = FTMRE_FSTAT_ACCERR_MASK | FTMRE_FSTAT_FPVIOL_MASK;

  return (RESULT_OK);

}

/*************************************************************************
 * Function Name: FlashWrite
 * Parameters: block base address, offet in block, data size, ram buffer
 *             pointer
 * Return:  0 - Write Successful
 *          1 - Write Fail
 * Description. Writes data to Flash
 *************************************************************************/
uint32_t FlashWrite(void *block_start,
                    uint32_t offset_into_block,
                    uint32_t count,
                    char const *buffer)
{
  uint32_t size;
  union
  {
    uint32_t  word;
    uint8_t   byte[4];
  } dest;

  /*Set Write command*/
  /* Clear error flags */
  FTMRE_FSTAT = 0x30;

  for(size = 0, dest.word = (uint32_t)block_start + offset_into_block;
      size < count; size += FLASH_PAGE_SIZE, dest.word += FLASH_PAGE_SIZE, buffer +=FLASH_PAGE_SIZE ) {

    /* Write index to specify the command code to be loaded */
    FTMRE_FCCOBIX = 0x0;
    /* Write command code and memory address bits[17:16] */
    FTMRE_FCCOBHI = FLASH_CMD_PROGRAM; /* program FLASH command */
    /*Set destination address*/
    FTMRE_FCCOBLO = dest.byte[2];/* memory address bits[23:16] */

    /* Write index to specify the lower byte memory address bits[15:0] to be loaded */
    FTMRE_FCCOBIX = 0x1;
    FTMRE_FCCOBHI = dest.byte[1];
    FTMRE_FCCOBLO = dest.byte[0];

    /* copy data */
    FTMRE_FCCOBIX = 0x2;
    FTMRE_FCCOBHI = buffer[1];
    FTMRE_FCCOBLO = buffer[0];
    FTMRE_FCCOBIX = 0x3;
    FTMRE_FCCOBHI = buffer[3];
    FTMRE_FCCOBLO = buffer[2];
    FTMRE_FCCOBIX = 0x4;
    FTMRE_FCCOBHI = buffer[5];
    FTMRE_FCCOBLO = buffer[4];
    FTMRE_FCCOBIX = 0x5;
    FTMRE_FCCOBHI = buffer[7];
    FTMRE_FCCOBLO = buffer[6];
    if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  }

  return(RESULT_OK);
}

/*************************************************************************
 * Function Name: FlashErase
 * Parameters:  Block Address, Block Size
 *
 * Return: 0
 *
 * Description: Erase flash block (NOTE: does not support  EEPROM erase)
 *************************************************************************/
uint32_t FlashErase(void *block_start,
                    uint32_t block_size)
{
union
{
  uint32_t  word;
  uint8_t   byte[4];
} dest;

  dest.word = (uint32_t)block_start;

  /* Clear error flags */
  FTMRE_FSTAT = 0x30;
  /* Write index to specify the command code to be loaded */
  FTMRE_FCCOBIX = 0x0;
  FTMRE_FCCOBHI = FLASH_CMD_ERASE_SECTOR; /* erase flash sector command */
  /*Set destination address*/
  FTMRE_FCCOBLO = dest.byte[2]; /* memory address bits[23:16] */
  FTMRE_FCCOBIX = 0x1;
  /* Write the lower byte memory address bits[15:0] */
  FTMRE_FCCOBHI = dest.byte[1];
  FTMRE_FCCOBLO = dest.byte[0];

  /* Execute Command sequence */
  if(RESULT_ERROR == CommandLaunch()) return RESULT_ERROR;
  return(RESULT_OK);
}

/** private functions **/
static uint32_t CommandLaunch(void)
{
  /* Launch command */
  FTMRE_FSTAT = 0x80;

  /* Wait till command is completed */
  while (!(FTMRE_FSTAT & FTMRE_FSTAT_CCIF_MASK));

  /* check for errors */
  if(FTMRE_FSTAT & (FTMRE_FSTAT_ACCERR_MASK | FTMRE_FSTAT_FPVIOL_MASK | FTMRE_FSTAT_MGSTAT_MASK))
  {
    FTMRE_FSTAT = FTMRE_FSTAT_ACCERR_MASK | FTMRE_FSTAT_FPVIOL_MASK;
    return(RESULT_ERROR);
  }
  /* No errors retur OK */
  return (RESULT_OK);
}
